import{W as n}from"./index-Caw8oHtK.js";class r extends n{async show(e){}async hide(e){}}export{r as SplashScreenWeb};
